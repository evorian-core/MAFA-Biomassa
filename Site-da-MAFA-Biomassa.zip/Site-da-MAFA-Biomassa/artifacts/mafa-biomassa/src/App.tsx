import { useEffect, useState, type FormEvent } from 'react';
import { ArrowUpRight, Menu, X } from 'lucide-react';

const whatsappNumber = '5542980188935';
const whatsappBase = `https://wa.me/${whatsappNumber}`;
const introMessage = 'Olá! Gostaria de conversar com a MAFA Biomassa sobre pellets de madeira.';
const logoSrc = `${import.meta.env.BASE_URL}mafa-logo.png`;

const faqItems = [
  {
    question: 'O que são pellets de madeira?',
    answer:
      'São pequenos cilindros produzidos a partir de biomassa de madeira. Em equipamentos preparados para esse combustível, são utilizados como fonte de energia térmica.',
  },
  {
    question: 'Em quais aplicações podem ser utilizados?',
    answer:
      'Pellets podem ser considerados em sistemas térmicos compatíveis, como caldeiras, fornos e aquecedores projetados para esse tipo de combustível. A compatibilidade depende do equipamento e da aplicação.',
  },
  {
    question: 'Como saber se minha operação é compatível?',
    answer:
      'O primeiro passo é compartilhar informações sobre o processo térmico, o equipamento utilizado e a região da operação. A equipe pode então entender a consulta e orientar os próximos passos.',
  },
  {
    question: 'Como funciona uma consulta comercial?',
    answer:
      'Você pode enviar uma mensagem pelo formulário ou WhatsApp. A mensagem abre como rascunho para revisão; depois de conferir, basta enviar pelo próprio WhatsApp. Nenhuma mensagem é enviada automaticamente.',
  },
  {
    question: 'Posso solicitar informações para uma parceria?',
    answer:
      'Sim. Use o canal de contato para apresentar sua empresa, o contexto da parceria e a melhor forma de retorno. A conversa inicial ajuda a direcionar a solicitação.',
  },
];

const contactHref = `${whatsappBase}?text=${encodeURIComponent(introMessage)}`;

function Brand() {
  return (
    <a href="#inicio" className="brand" aria-label="MAFA Biomassa — início" data-testid="link-brand-home">
      <img className="brand-logo" src={logoSrc} alt="" aria-hidden="true" />
      <span>
        <span className="brand-name">MAFA</span>
        <span className="brand-sub">Biomassa</span>
      </span>
    </a>
  );
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  useEffect(() => {
    const nodes = document.querySelectorAll<HTMLElement>('.reveal');
    if (!('IntersectionObserver' in window)) {
      nodes.forEach((node) => node.classList.add('is-visible'));
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.12 },
    );
    nodes.forEach((node) => observer.observe(node));
    return () => observer.disconnect();
  }, []);

  function handleInquiry(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) return;
    const data = new FormData(form);
    const message = [
      'Olá! Gostaria de conversar com a MAFA Biomassa.',
      '',
      `Nome: ${String(data.get('name') || '').trim()}`,
      `Empresa: ${String(data.get('company') || '').trim() || 'Não informado'}`,
      `E-mail: ${String(data.get('email') || '').trim()}`,
      `Telefone: ${String(data.get('phone') || '').trim() || 'Não informado'}`,
      `Assunto: ${String(data.get('subject') || '').trim()}`,
      '',
      `Mensagem: ${String(data.get('message') || '').trim()}`,
    ].join('\n');
    const url = `${whatsappBase}?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="site-shell">
      <header className="container topbar" id="inicio">
        <Brand />
        <button
          className="menu-button"
          type="button"
          aria-label={menuOpen ? 'Fechar navegação' : 'Abrir navegação'}
          aria-expanded={menuOpen}
          aria-controls="site-navigation"
          onClick={() => setMenuOpen((value) => !value)}
          data-testid="button-mobile-menu"
        >
          {menuOpen ? <X size={22} strokeWidth={1.6} /> : <Menu size={22} strokeWidth={1.6} />}
        </button>
        <nav id="site-navigation" className={`nav-links${menuOpen ? ' open' : ''}`} aria-label="Navegação principal">
          <a href="#mafa" onClick={closeMenu} data-testid="link-nav-mafa">A MAFA</a>
          <a href="#pellets" onClick={closeMenu} data-testid="link-nav-pellets">Pellets</a>
          <a href="#conversa" onClick={closeMenu} data-testid="link-nav-processo">Como conversar</a>
          <a href="#duvidas" onClick={closeMenu} data-testid="link-nav-duvidas">Dúvidas</a>
          <a href="#contato" onClick={closeMenu} className="nav-cta" data-testid="link-nav-contato">Fale com a MAFA <ArrowUpRight size={14} /></a>
        </nav>
      </header>

      <main>
        <section className="container hero" aria-labelledby="hero-title">
          <div className="hero-copy">
            <span className="eyebrow reveal">Biomassa para energia térmica</span>
            <h1 className="reveal reveal-delay" id="hero-title">Energia que <em>move</em> o futuro.</h1>
            <p className="hero-lead reveal reveal-delay">
              Pellets de madeira como combustível para processos térmicos. Uma conversa clara começa entendendo a necessidade da sua operação.
            </p>
            <div className="hero-actions reveal reveal-delay">
              <a href={contactHref} target="_blank" rel="noreferrer" className="button-primary" data-testid="link-hero-whatsapp">
                Converse com a MAFA <ArrowUpRight className="arrow" size={17} />
              </a>
              <a href="#pellets" className="text-link" data-testid="link-hero-saiba-mais">Conheça os pellets</a>
            </div>
            <div className="hero-note reveal reveal-delay">Uma fonte de energia em formato simples</div>
          </div>
          <div className="hero-art reveal reveal-delay" aria-label="Ilustração botânica de folhas e uma chama em tons de verde e cobre" role="img">
            <div className="hero-art-glow" aria-hidden="true" />
            <svg className="hero-illustration" viewBox="0 0 520 520" aria-hidden="true">
              <path className="hero-stem" d="M239 467 C248 405 230 345 255 283 C278 226 326 177 324 104" />
              <path className="hero-leaf hero-leaf-deep" d="M253 341 C159 337 106 279 111 197 C188 196 244 242 253 341Z" />
              <path className="hero-vein" d="M242 323 C207 280 164 235 122 205" />
              <path className="hero-leaf hero-leaf-soft" d="M267 256 C272 178 323 127 396 117 C394 189 349 242 267 256Z" />
              <path className="hero-vein" d="M279 240 C313 196 350 156 385 126" />
              <path className="hero-leaf hero-leaf-deep" d="M239 418 C170 415 128 376 122 320 C184 317 222 354 239 418Z" />
              <path className="hero-vein" d="M228 401 C201 369 166 342 134 328" />
              <path className="hero-flame" d="M258 445 C244 387 297 351 293 304 C290 267 314 223 356 180 C400 233 418 285 396 335 C377 380 332 418 258 445Z" />
              <path className="hero-flame-inner" d="M294 415 C285 384 338 354 333 321 C329 296 346 270 365 248 C387 285 388 314 371 342 C355 371 327 398 294 415Z" />
              <g className="hero-pellets">
                <rect x="180" y="440" width="37" height="13" rx="6.5" transform="rotate(-12 198 446)" />
                <rect x="221" y="447" width="39" height="13" rx="6.5" transform="rotate(8 240 453)" />
                <rect x="264" y="439" width="37" height="13" rx="6.5" transform="rotate(-10 282 445)" />
              </g>
            </svg>
            <span className="art-caption a">Folhas · energia</span>
            <span className="art-index">MAFA / 01</span>
            <span className="hero-side-note">Energia com origem renovável</span>
          </div>
        </section>

        <div className="ticker" aria-label="MAFA Biomassa — energia que move o futuro">
          <div className="container ticker-inner">
            <span>Energia térmica</span><span className="dot" aria-hidden="true">◆</span>
            <span>Pellets de madeira</span><span className="dot" aria-hidden="true">◆</span>
            <span>Biomassa</span><span className="dot" aria-hidden="true">◆</span>
            <span>Energia que move o futuro</span>
          </div>
        </div>

        <section className="section about" id="mafa">
          <div className="container about-grid">
            <div className="reveal">
              <span className="eyebrow">01 — Quem somos</span>
              <p className="about-mark">Uma ponte entre a biomassa e as necessidades de energia da sua operação.<span>MAFA Biomassa</span></p>
            </div>
            <div className="about-copy reveal reveal-delay">
              <h2>Energia mais próxima da <em>realidade</em> de cada negócio.</h2>
              <p>A MAFA Biomassa aproxima empresas de uma alternativa de combustível para geração de energia térmica: os pellets de madeira.</p>
              <p>Nosso primeiro passo é ouvir. Cada processo tem suas particularidades, e uma boa conversa ajuda a entender o contexto, a aplicação e as informações necessárias para avançar.</p>
              <div className="about-rule"><span>Biomassa em pauta</span><span>Conversa sem complicação</span></div>
            </div>
          </div>
        </section>

        <section className="section fuel" id="pellets">
          <div className="container fuel-layout">
            <div className="fuel-visual reveal" role="img" aria-label="Ilustração de pellets de madeira em uma composição botânica">
              <span className="fuel-visual-label">Da matéria à energia</span>
              <svg className="pellet-illustration" viewBox="0 0 480 470" aria-hidden="true">
                <defs>
                  <linearGradient id="pellet-wood" x1="0" y1="0" x2="1" y2="0">
                    <stop offset="0" stopColor="#9f6544" />
                    <stop offset=".48" stopColor="#c58b62" />
                    <stop offset="1" stopColor="#a96f4b" />
                  </linearGradient>
                </defs>
                <path className="pellet-sprig" d="M118 351 C143 288 153 220 133 132" />
                <path className="pellet-leaf" d="M138 266 C96 252 75 219 74 178 C114 191 138 221 138 266Z" />
                <path className="pellet-leaf-vein" d="M132 254 C112 227 94 204 79 185" />
                <path className="pellet-leaf" d="M143 214 C177 191 185 159 176 125 C146 143 132 173 143 214Z" />
                <path className="pellet-leaf-vein" d="M145 202 C157 177 166 153 174 132" />
                <path className="pellet-sprig" d="M361 352 C337 294 328 228 348 157" />
                <path className="pellet-leaf pellet-leaf-copper" d="M337 273 C378 256 397 222 397 185 C358 199 336 229 337 273Z" />
                <path className="pellet-leaf-vein" d="M343 258 C365 233 381 212 392 192" />
                <ellipse className="pellet-shadow" cx="245" cy="372" rx="138" ry="15" />
                <g className="wood-pellet" transform="translate(166 292) rotate(-48)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" fill="url(#pellet-wood)" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
                <g className="wood-pellet" transform="translate(215 279) rotate(-22)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" fill="url(#pellet-wood)" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
                <g className="wood-pellet" transform="translate(263 286) rotate(13)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" fill="url(#pellet-wood)" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
                <g className="wood-pellet" transform="translate(310 300) rotate(47)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
                <g className="wood-pellet" transform="translate(195 336) rotate(36)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
                <g className="wood-pellet" transform="translate(253 339) rotate(-31)">
                  <rect x="-19" y="-55" width="38" height="110" rx="17" />
                  <ellipse cx="0" cy="-39" rx="14" ry="7" />
                  <ellipse className="pellet-core" cx="0" cy="-39" rx="5" ry="2.5" />
                  <path className="pellet-grain" d="M-10 16 C-3 20 4 20 11 16" />
                </g>
              </svg>
              <span className="fuel-visual-count">02</span>
            </div>
            <div className="fuel-content reveal reveal-delay">
              <span className="eyebrow">02 — Entenda o combustível</span>
              <h2>Pequenos no formato.<br /><em>Relevantes</em> no processo.</h2>
              <p>Pellets são pequenos cilindros feitos de biomassa de madeira. Em equipamentos compatíveis, podem alimentar processos que precisam de energia térmica.</p>
              <ul className="use-list">
                <li>Caldeiras preparadas para pellets</li>
                <li>Fornos compatíveis com o combustível</li>
                <li>Aquecedores projetados para biomassa</li>
              </ul>
              <p className="fine-print">A adequação depende do equipamento e das condições de cada aplicação. Converse com a MAFA para apresentar seu cenário.</p>
            </div>
          </div>
        </section>

        <section className="section process" id="conversa">
          <div className="container">
            <div className="section-heading reveal">
              <div><span className="eyebrow">03 — Um bom começo</span><h2>Da primeira mensagem ao <em>próximo passo.</em></h2></div>
              <p>Um contato comercial começa com contexto. Assim, a conversa pode ser direcionada para o que sua operação realmente precisa saber.</p>
            </div>
            <div className="steps">
              <article className="step reveal"><span className="step-no">01 / CONTEXTO</span><h3>Conte sobre sua operação</h3><p>Compartilhe sua aplicação térmica, localização e o que gostaria de avaliar.</p></article>
              <article className="step reveal reveal-delay"><span className="step-no">02 / CONVERSA</span><h3>Alinhamos a necessidade</h3><p>A consulta ajuda a compreender o cenário e identificar quais informações fazem sentido para seguir.</p></article>
              <article className="step reveal reveal-delay"><span className="step-no">03 / DIRECIONAMENTO</span><h3>Defina os próximos passos</h3><p>Com o contexto em mãos, a conversa pode avançar de forma objetiva e adequada à solicitação.</p></article>
            </div>
            <div className="process-bottom reveal">
              <p>Sem complicar o que pode começar com uma boa pergunta.</p>
              <a href={contactHref} target="_blank" rel="noreferrer" className="button-primary button-light" data-testid="link-processo-whatsapp">Iniciar uma conversa <ArrowUpRight size={16} /></a>
            </div>
          </div>
        </section>

        <section className="section faq" id="duvidas">
          <div className="container faq-grid">
            <div className="faq-intro reveal">
              <span className="eyebrow">04 — Perguntas frequentes</span>
              <h2>Antes de <em>conversar.</em></h2>
              <p>Respostas diretas para ajudar você a entender onde os pellets podem fazer sentido.</p>
            </div>
            <div className="faq-list reveal reveal-delay">
              {faqItems.map((item, index) => {
                const expanded = openFaq === index;
                const answerId = `faq-answer-${index + 1}`;
                return (
                  <div className="faq-item" data-open={expanded} key={item.question}>
                    <button
                      className="faq-question"
                      type="button"
                      aria-expanded={expanded}
                      aria-controls={answerId}
                      onClick={() => setOpenFaq(expanded ? null : index)}
                      data-testid={`button-faq-${index + 1}`}
                    >
                      <span>{item.question}</span><span className="faq-toggle" aria-hidden="true">+</span>
                    </button>
                    {expanded && <div className="faq-answer" id={answerId} role="region">{item.answer}</div>}
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="contact" id="contato">
          <div className="container contact-grid">
            <div className="contact-copy reveal">
              <span className="eyebrow">05 — Contato</span>
              <h2>Vamos falar da sua <em>operação?</em></h2>
              <p>Compartilhe um pouco do que procura. Sua mensagem será preparada no WhatsApp para você revisar e enviar.</p>
              <div className="contact-details">
                <span>Canal de contato</span>
                <a href={contactHref} target="_blank" rel="noreferrer" data-testid="link-contact-phone">+55 (42) 98018-8935 <ArrowUpRight size={15} /></a>
              </div>
            </div>
            <form className="form-panel reveal reveal-delay" onSubmit={handleInquiry} data-testid="form-inquiry">
              <h3>Inicie uma conversa</h3>
              <p>Preencha os campos e confira sua mensagem no WhatsApp.</p>
              <div className="field-row">
                <div className="field"><label htmlFor="name">Seu nome *</label><input id="name" name="name" autoComplete="name" required maxLength={100} placeholder="Como podemos chamar você?" data-testid="input-name" /></div>
                <div className="field"><label htmlFor="company">Empresa</label><input id="company" name="company" autoComplete="organization" maxLength={120} placeholder="Nome da empresa" data-testid="input-company" /></div>
              </div>
              <div className="field-row">
                <div className="field"><label htmlFor="email">E-mail *</label><input id="email" name="email" type="email" autoComplete="email" required maxLength={160} placeholder="voce@empresa.com.br" data-testid="input-email" /></div>
                <div className="field"><label htmlFor="phone">Telefone</label><input id="phone" name="phone" type="tel" autoComplete="tel" maxLength={30} placeholder="(00) 00000-0000" data-testid="input-phone" /></div>
              </div>
              <div className="field">
                <label htmlFor="subject">Assunto *</label>
                <select id="subject" name="subject" required defaultValue="" data-testid="select-subject">
                  <option value="" disabled>Selecione um assunto</option>
                  <option value="Consulta sobre pellets">Consulta sobre pellets</option>
                  <option value="Aplicação térmica">Aplicação térmica</option>
                  <option value="Parceria comercial">Parceria comercial</option>
                  <option value="Outro assunto">Outro assunto</option>
                </select>
              </div>
              <div className="field"><label htmlFor="message">Como podemos ajudar? *</label><textarea id="message" name="message" required maxLength={1200} placeholder="Conte brevemente sobre sua necessidade..." data-testid="input-message" /></div>
              <button className="button-primary submit-button" type="submit" data-testid="button-submit-inquiry">Preparar mensagem no WhatsApp <ArrowUpRight size={16} /></button>
              <p className="whatsapp-note">O WhatsApp abrirá com a mensagem preenchida. Você poderá revisar e enviar por conta própria.</p>
              <p className="form-footnote">* Campos obrigatórios. Seus dados não são armazenados por este site.</p>
            </form>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="container">
          <div className="footer-main">
            <Brand />
            <p className="footer-center">Energia que move o futuro.</p>
            <a href={contactHref} target="_blank" rel="noreferrer" className="button-primary button-light" data-testid="link-footer-whatsapp">Fale com a MAFA <ArrowUpRight size={15} /></a>
          </div>
          <div className="footer-bottom">
            <span>MAFA Biomassa · Pellets de madeira</span>
            <span className="footer-credit">EVORIAN — OMNIA.</span>
          </div>
          <p className="form-footnote">Contato sujeito à confirmação final antes da publicação.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;